export class Contact {
    name: string="";
    email: string="";
    comment: string="";
}
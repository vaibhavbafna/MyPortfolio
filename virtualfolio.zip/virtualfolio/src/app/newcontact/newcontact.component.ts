import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcontact',
  templateUrl: './newcontact.component.html',
  styleUrls: ['./newcontact.component.css']
})
export class NewcontactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
